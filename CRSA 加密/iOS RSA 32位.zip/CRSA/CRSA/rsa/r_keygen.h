
//#include "rsa.h"
//int R_GeneratePEMKeys (R_RSA_PUBLIC_KEY *, R_RSA_PRIVATE_KEY *, 
//					  R_RSA_PROTO_KEY *, R_RANDOM_STRUCT *);
