//
//  AppDelegate.h
//  CRSA
//
//  Created by 糊涂 on 15/2/13.
//  Copyright (c) 2015年 hutu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

