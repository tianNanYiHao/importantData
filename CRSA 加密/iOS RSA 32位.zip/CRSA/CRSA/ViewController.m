//
//  ViewController.m
//  CRSA
//
//  Created by 糊涂 on 15/2/13.
//  Copyright (c) 2015年 hutu. All rights reserved.
//

#import "ViewController.h"
#include "rsa.h"
#include "r_random.h"
#import "QuickPos.h"

@interface ViewController ()

@end
@implementation ViewController


//R_RSA_PUBLIC_KEY publicKey ;
//unsigned char pubKey1[] = "9D1265CE087D159D5C760B391A613ECC2BB4F3A6D9911A8A523A36E738F506DB9FB3084E91190FB4942F5544E88A0E20A6398F7F55C8ECBDD2B3218DD79AE88029611A8A30B80E1DFD7F6F0B0D0E22D0F50405955B2B886C511B2F247A2C2A046543B4B14E3834612BB5ECF5846AF2E0CAFB9B3D7A801D3DF9357789653EED59";
//
//unsigned char pubKey2[] = "A8C12720E3A6A5F224058D1CB4D57FB4522521D2BBD025CA80105826B335079862A294F97C129E59B9ED5B497EF5B6AD17AFDE482AB9C22E0499444039E18845A70F59028F367175253973CDF180C2E97DFAB7C0E12B22E2E241ACCB5A58EBC15344F956A7806B1F02ADDB354E4FCA0185268542F7780456187F10B9D6FF5995";

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    unsigned char output[256] = {0};          /* output block */
//    unsigned int outputLen;        /* length of output block */
//    unsigned char* inDa = {0};
//    unsigned char input[] = "0000000000061111112015011309082018917596737";
//    unsigned int inputLen = 43;          /* length of input block */
////    unsigned int inputLen = 256;
//    
//    unsigned char pubKey[] = "A8C12720E3A6A5F224058D1CB4D57FB4522521D2BBD025CA80105826B335079862A294F97C129E59B9ED5B497EF5B6AD17AFDE482AB9C22E0499444039E18845A70F59028F367175253973CDF180C2E97DFAB7C0E12B22E2E241ACCB5A58EBC15344F956A7806B1F02ADDB354E4FCA0185268542F7780456187F10B9D6FF5995";
//    unsigned int pubKeyLen = 128 + 11;
//    
//    publicKey.bits = 1024;
//    
//    TOOL_Asc2Hex(publicKey.modulus, 128, pubKey, 256);
//    TOOL_Asc2Hex(publicKey.exponent, 128, "010001", 6);
//
//    
////    int rsapub = rsapublicfunc(output, &outputLen, pubKey, pubKeyLen, &publicKey);
//    R_RANDOM_STRUCT random = *InitRandomStruct();
//    
//    int pubEnc = RSAPublicEncrypt(output, &outputLen, input, inputLen, &publicKey, &random);
    
    
    NSString *str = [[[QuickPos alloc] init] enCodeWithName:@"糊涂一二三四五六七八九十" IDCard:@"130102199911112112" cardNo:@"1234567890123456" vaild:@"" cvv2:@"" phone:@"13817434102"];
    NSLog(@"resp %@", str);
}

//- (NSString *)enCodeWithData:(NSString*)data enCodeType:(BOOL)type account:(NSString*)account{
//    
//    NSString *strHead = type?@"FFFFFFFF":@"00000000";
//    NSString *psdLength = [NSString stringWithFormat:@"%ld", [data length]];
//    NSString *strIn;
//    if ([psdLength length] % 2 == 1) {
//        strIn = [NSString stringWithFormat:@"%@0%@", strHead, psdLength];
//    }else{
//        strIn = [NSString stringWithFormat:@"%@%@", strHead, psdLength];
//    }
//    
//    strIn = [strIn stringByAppendingString:data];
//    NSDateFormatter *format = [[NSDateFormatter alloc] init];
//    [format setDateFormat:@"yyyyMMddhhmmss"];
//    NSString *strDate = [format stringFromDate:[NSDate date]];
//    
//    strIn = [NSString stringWithFormat:@"%@%@%@", strIn, strDate, account];
//    
//    
//    unsigned char *pubKey = type?pubKey1:pubKey2;
//    
//    unsigned char output[256] = {0};          /* output block */
//    unsigned int outputLen;        /* length of output block */
//    unsigned char* inDa = {0};
//    unsigned char *input = [strIn cStringUsingEncoding:NSASCIIStringEncoding];
//    unsigned int inputLen = strIn.length;          /* length of input block */
//    //    unsigned int inputLen = 256;
//    
//    unsigned int pubKeyLen = 128 + 11;
//    
//    R_RSA_PUBLIC_KEY publicKey;
//    publicKey.bits = 1024;
//    
//    TOOL_Asc2Hex(publicKey.modulus, 128, pubKey, 256);
//    TOOL_Asc2Hex(publicKey.exponent, 128, "010001", 6);
//    
//    
////    int rsapub = rsapublicfunc(output, &outputLen, pubKey, pubKeyLen, &publicKey);
//    R_RANDOM_STRUCT random = *InitRandomStruct();
//    
//    int pubEnc = RSAPublicEncrypt(output, &outputLen, input, inputLen, &publicKey, &random);
//    
////    NSString *code = [[NSString alloc] initWithBytes:output length:outputLen encoding:NSASCIIStringEncoding];
//    NSData *odata = [[NSData alloc] initWithBytes:output length:outputLen];
//    
//    NSString *code = [self hexFromData:odata];
//    return code;
//}
//
//- (NSString*)hexFromData:(NSData*)data{
//    Byte *bytes = (Byte *)[data bytes];
//    //下面是Byte 转换为16进制。
//    NSString *hexStr=@"";
//    for(int i=0;i<[data length];i++)
//        
//    {
//        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
//        
//        if([newHexStr length]==1)
//            
//            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
//        
//        else
//            
//            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
//    }
//    return hexStr;
//}
//
//static R_RANDOM_STRUCT *InitRandomStruct(void)
//{
//    static unsigned char seedByte = 0;
//    unsigned int bytesNeeded;
//    static R_RANDOM_STRUCT randomStruct;
//    
//    R_RandomInit(&randomStruct);
//    
//    /* Initialize with all zero seed bytes, which will not yield an actual
//     random number output. */
//    
//    while (1) {
//        R_GetRandomBytesNeeded(&bytesNeeded, &randomStruct);
//        if(bytesNeeded == 0)
//            break;
//        
//        R_RandomUpdate(&randomStruct, &seedByte, 1);
//    }
//    
//    return(&randomStruct);
//}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}

@end
