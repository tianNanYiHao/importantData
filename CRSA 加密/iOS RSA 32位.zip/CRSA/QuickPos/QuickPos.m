//
//  QuickPos.m
//  QuickPos
//
//  Created by 糊涂 on 15/3/18.
//  Copyright (c) 2015年 hutu. All rights reserved.
//

#import "QuickPos.h"
#include "rsa.h"
#include "r_random.h"


@implementation QuickPos

unsigned char pubKey1[] = "9D1265CE087D159D5C760B391A613ECC2BB4F3A6D9911A8A523A36E738F506DB9FB3084E91190FB4942F5544E88A0E20A6398F7F55C8ECBDD2B3218DD79AE88029611A8A30B80E1DFD7F6F0B0D0E22D0F50405955B2B886C511B2F247A2C2A046543B4B14E3834612BB5ECF5846AF2E0CAFB9B3D7A801D3DF9357789653EED59";

unsigned char pubKey2[] = "A8C12720E3A6A5F224058D1CB4D57FB4522521D2BBD025CA80105826B335079862A294F97C129E59B9ED5B497EF5B6AD17AFDE482AB9C22E0499444039E18845A70F59028F367175253973CDF180C2E97DFAB7C0E12B22E2E241ACCB5A58EBC15344F956A7806B1F02ADDB354E4FCA0185268542F7780456187F10B9D6FF5995";

unsigned char pubKey3[] = "ADF13DA14F04626E938809E14EEDD940AA3FEF04CA2C3EFDB033DD21BE9D6B3A8D6F7CCE7CBB2BD00A3F13389325867EB2E7A661D999D789F9364D468EE70521A1A85C2BE70A5855AE37E2740DF49AF62EDCA281FA9A7DAB936946A4386E337D4193520FE1D57AB067505A3BA6A2D6510B63424BD51ABBB042BCCE7F2F51D317";

- (NSString *)enCodeWithData:(NSString*)data enCodeType:(BOOL)type account:(NSString*)account{
    
    NSString *strHead = nil;
    unsigned char *pubKey;
    
    NSString *strIn = nil;
    
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyyMMddHHmmss"];
    NSString *strDate = [format stringFromDate:[NSDate date]];
    
    if (type) {
        strHead = @"FFFFFFFF";
        pubKey = pubKey1;
        NSString *cardID = @"";
        if ([account length] >= 16) {
            cardID = [account substringFromIndex:[account length] - 16];
        } else {
            for (int i = 0; i < 16 - [account length]; i++) {
                cardID = [cardID stringByAppendingString:@"0"];
            }
        }
        
        strIn = [NSString stringWithFormat:@"%@%@%@%@", strHead, cardID, data, strDate];
        
    }else{
        strHead = @"00000000";
        pubKey = pubKey2;
        NSString *psdLength = [NSString stringWithFormat:@"%ld", (long)[data length]];
        if ([psdLength length] % 2 == 1) {
            strIn = [NSString stringWithFormat:@"%@0%@", strHead, psdLength];
        }else{
            strIn = [NSString stringWithFormat:@"%@%@", strHead, psdLength];
        }
        strIn = [strIn stringByAppendingString:data];
        
        strIn = [NSString stringWithFormat:@"%@%@%@", strIn, strDate, account];
    }
    
    return [self enCodeWithData:strIn key:pubKey];
    
}

- (NSString *)enCodeWithName:(NSString*)name IDCard:(NSString*)IDCard cardNo:(NSString*)cardNo vaild:(NSString*)vaild cvv2:(NSString*)cvv2 phone:(NSString*)phone {
//    String data = "00000000" + name + "&" + IDCard + "&" + cardNo + "&"
//    + vaild + "&" + cvv2 + "&" + phone;
    
    if (!vaild) {
        vaild = @"";
    }
    
    if (!cvv2) {
        cvv2 = @"";
    }
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGBK_95);
    name = [self hexFromData:[name dataUsingEncoding:enc]];
    
    NSString *data = [NSString stringWithFormat:@"00000000&%@&%@&%@&%@&%@&%@", name, IDCard, cardNo, vaild, cvv2, phone];
    
    return [self enCodeWithData:data key:pubKey3];
}

- (NSString *)enCodeWithData:(NSString*)data key:(unsigned char*)pubKey{
    
    unsigned char output[256] = {0};          /* output block */
    unsigned int outputLen;        /* length of output block */
    unsigned char* inDa = {0};
    unsigned char *input = [data cStringUsingEncoding:NSUTF8StringEncoding];
    unsigned int inputLen = data.length;          /* length of input block */
    //    unsigned int inputLen = 256;
    
    unsigned int pubKeyLen = 128 + 11;
    
    R_RSA_PUBLIC_KEY publicKey;
    publicKey.bits = 1024;
    
    TOOL_Asc2Hex(publicKey.modulus, 128, pubKey, 256);
    TOOL_Asc2Hex(publicKey.exponent, 128, "010001", 6);
    
    
    int rsapub = rsapublicfunc(output, &outputLen, pubKey, pubKeyLen, &publicKey);
    R_RANDOM_STRUCT random = *InitRandomStruct();
    
    int pubEnc = RSAPublicEncrypt(output, &outputLen, input, inputLen, &publicKey, &random);
    
    //    NSString *code = [[NSString alloc] initWithBytes:output length:outputLen encoding:NSASCIIStringEncoding];
    NSData *odata = [[NSData alloc] initWithBytes:output length:outputLen];
    
    NSString *code = [self hexFromData:odata];
    return code;
}

- (NSString*)hexFromData:(NSData*)data{
    Byte *bytes = (Byte *)[data bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[data length];i++)
        
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%X",bytes[i]&0xff];///16进制数
        
        if([newHexStr length]==1)
            
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        
        else
            
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr;
}

static R_RANDOM_STRUCT *InitRandomStruct(void)
{
    static unsigned char seedByte = 0;
    unsigned int bytesNeeded;
    static R_RANDOM_STRUCT randomStruct;
    
    R_RandomInit(&randomStruct);
    
    /* Initialize with all zero seed bytes, which will not yield an actual
     random number output. */
    
    while (1) {
        R_GetRandomBytesNeeded(&bytesNeeded, &randomStruct);
        if(bytesNeeded == 0)
            break;
        
        R_RandomUpdate(&randomStruct, &seedByte, 1);
    }
    
    return(&randomStruct);
}

@end
