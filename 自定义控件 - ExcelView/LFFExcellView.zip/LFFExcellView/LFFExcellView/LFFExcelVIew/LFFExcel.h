//
//  LFFExcel.h
//  LFFExcellView
//
//  Created by Lff on 16/8/18.
//  Copyright © 2016年 Lff. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LFFExcel : NSObject

@end



@interface LFFExcelData : NSObject
{
    NSMutableArray *titles;  //标题列表
    NSMutableArray *data ;  //excel数据 (数组[数组,数组,数组])
    float excelWidth; // 表格宽
    float excelX;   //表格x
    float excelY;   //表格y
    float cellHeight; //单元格高
    float cellwidth; //单元格宽
    
    
    
}
@property(retain) NSMutableArray *titles;
@property(retain) NSMutableArray *data;
@property (assign)float excelWidth;
@property (assign)float excelX;
@property (assign)float excelY;
@property (assign)float cellHeight;
@property (assign)float cellwidth;
//获取表格的总高
-(float)initwithexcelWidthBycellHeight:(float)cellHeight;
//获取单元格的宽度
-(float)cellwidthByexcelWidth:(float)excelWidth excelX:(float)excelX;
@end


@interface LFFExcelScrollView : UIScrollView
{
    
}
@end


@interface LFFExcelComponent : UIView<UIScrollViewDelegate>{
    //上标题
    UIView *vTopLeft;
    //ecxel 行view
    UIView *vRowView;
    //单元格view
    UIView *vCellView;
    
    //列表数据源
    LFFExcelData *dataSource;

    
    //单元格默认宽度
    float cellWidth;
    
    //单元格默认高度
    float cellHeight;
    
    
    

}
@property(readonly) float cellHeight;
@property(readonly) float cellWidth;
@property(retain) LFFExcelData *dataSource;

//用frame 和 数据源 初始化
-(instancetype)initWithFrame:(CGRect)frame data:(LFFExcelData*)DataSource cellW:(int)w cellheight:(int)h;


@end

