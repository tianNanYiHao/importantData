//
//  ViewController.m
//  LFFExcellView
//
//  Created by Lff on 16/8/18.
//  Copyright © 2016年 Lff. All rights reserved.
//

#import "ViewController.h"
#import "LFFExcel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //数据初始化
    LFFExcelData *ds = [[LFFExcelData alloc] init];
    //标题栏数据
    ds.titles = (NSMutableArray*)@[@"时长",@"流量",@"网络",@"地点"];
    //数据栏数据
    ds.data = [NSMutableArray arrayWithObjects:
               @[@"10:01",@"15.6M",@"3G",@"上海1"],
               @[@"10:01",@"15.6M",@"3G",@"上海2"],
               @[@"10:01",@"15.6M",@"3G",@"上海3"],
               @[@"10:01",@"15.6M",@"3G",@"上海4"],
               @[@"10:01",@"15.6M",@"3G",@"上海5"],
               @[@"10:01",@"15.6M",@"3G",@"上海6"],
               @[@"10:01",@"15.6M",@"3G",@"上海7"],
               @[@"10:01",@"15.6M",@"3G",@"上海8"],
               @[@"10:01",@"15.6M",@"3G",@"上海9"],
               @[@"",@"",@"",@""],@[@"",@"",@"",@""],@[@"",@"",@"",@""],@[@"",@"",@"",@""],
               nil];
    
    //设置表格的宽度
    ds.excelWidth = 300;
    //设置表格的x
    ds.excelX = 10;
    //设置表格的y
    ds.excelY = 100;
    //设置表格的单元格高度
    ds.cellHeight = 40;
    
    //根据单元格高度 获取exce表格的总高
    float excelheight  =   [ds initwithexcelWidthBycellHeight:ds.cellHeight];
    //根据titles获取单元格长度
    float cellWidth = [ds cellwidthByexcelWidth:ds.excelWidth excelX:ds.excelX];
    //excel初始化
    LFFExcelComponent *excel =
    [[LFFExcelComponent alloc] initWithFrame:CGRectMake(ds.excelX, ds.excelY, ds.excelWidth, excelheight) data:ds cellW:cellWidth cellheight: ds.cellHeight];
    
    
    
    excel.layer.borderColor = [UIColor blueColor].CGColor;
    excel.layer.borderWidth = 1;
    [self.view addSubview:excel];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
