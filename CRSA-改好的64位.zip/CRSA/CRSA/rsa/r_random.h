#include "rsa.h"
int R_GenerateBytes 
  (unsigned char *, unsigned int, R_RANDOM_STRUCT *);
int R_GetRandomBytesNeeded  (unsigned int *, R_RANDOM_STRUCT *);
int R_RandomInit(R_RANDOM_STRUCT *);
int R_RandomUpdate(R_RANDOM_STRUCT *, unsigned char *, unsigned int);